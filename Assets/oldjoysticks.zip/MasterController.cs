﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class MasterController : Joystick
{
    [SerializeField] private float moveThreshold = 1;
    [SerializeField] private JoystickType _joystickType = JoystickType.Fixed;

    private Vector2 fixedPosition = Vector2.zero;

    public float MoveThreshold
    {
        get { return MoveThreshold; }
        set { MoveThreshold = Mathf.Abs(value); }
    }

    public void SetMode(JoystickType joystickType)
    {
        joystickType = _joystickType;
        if (_joystickType == JoystickType.Fixed)
        {

        }

        switch(_joystickType)
        {
            case JoystickType.Fixed:
                _background.anchoredPosition = fixedPosition;
                _background.gameObject.SetActive(true);
                break;
            case JoystickType.Floating:

                break;
            case JoystickType.Dynamic:

                break;
        }
    }

    protected override void Start()
    {
        base.Start();
        fixedPosition = _background.anchoredPosition;
        SetMode(_joystickType);
    }

    public override void OnPointerDown(PointerEventData eventData)
    {
        //if 
    }

    public override void OnPointerUp(PointerEventData eventData)
    {
        if (_joystickType != JoystickType.Fixed)
        {
            _background.gameObject.SetActive(false);
        }
        base.OnPointerUp(eventData);
    }

    protected override void HandleInput(float magnitude, Vector2 normalised, Vector2 radius, Camera cam)
    {
        if (_joystickType == JoystickType.Dynamic && magnitude > moveThreshold)
        {
            Vector2 difference = normalised * (magnitude - moveThreshold) * radius;
            _background.anchoredPosition += difference;
        }
        base.HandleInput(magnitude, normalised, radius, cam);
    }
}

public enum JoystickType
{
    Fixed,
    Floating,
    Dynamic
}